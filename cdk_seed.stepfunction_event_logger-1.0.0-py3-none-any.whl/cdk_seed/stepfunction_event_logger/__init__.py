"""
# `@cdk-seed/stepfunction-event-logger`

> TODO: description

## Usage

```
const stepfunctionEventLogger = require('@cdk-seed/stepfunction-event-logger');

// TODO: DEMONSTRATE API
```
"""
import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

from ._jsii import *

import aws_cdk.aws_lambda
import aws_cdk.aws_stepfunctions
import aws_cdk.core


@jsii.enum(jsii_type="@cdk-seed/stepfunction-event-logger.Datastore")
class Datastore(enum.Enum):
    """
    :stability: experimental
    """

    DYNAMODB = "DYNAMODB"
    """
    :stability: experimental
    """
    POSTGRES = "POSTGRES"
    """
    :stability: experimental
    """


@jsii.data_type(
    jsii_type="@cdk-seed/stepfunction-event-logger.EventLoggerBaseProps",
    jsii_struct_bases=[],
    name_mapping={"stepfunctions": "stepfunctions"},
)
class EventLoggerBaseProps:
    def __init__(
        self,
        *,
        stepfunctions: typing.List[aws_cdk.aws_stepfunctions.StateMachine],
    ) -> None:
        """
        :param stepfunctions: 

        :stability: experimental
        """
        self._values: typing.Dict[str, typing.Any] = {
            "stepfunctions": stepfunctions,
        }

    @builtins.property
    def stepfunctions(self) -> typing.List[aws_cdk.aws_stepfunctions.StateMachine]:
        """
        :stability: experimental
        """
        result = self._values.get("stepfunctions")
        assert result is not None, "Required property 'stepfunctions' is missing"
        return result

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "EventLoggerBaseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdk-seed/stepfunction-event-logger.EventLoggerCustomLambdaProps",
    jsii_struct_bases=[EventLoggerBaseProps],
    name_mapping={"stepfunctions": "stepfunctions", "lambda_": "lambda"},
)
class EventLoggerCustomLambdaProps(EventLoggerBaseProps):
    def __init__(
        self,
        *,
        stepfunctions: typing.List[aws_cdk.aws_stepfunctions.StateMachine],
        lambda_: aws_cdk.aws_lambda.Function,
    ) -> None:
        """
        :param stepfunctions: 
        :param lambda_: 

        :stability: experimental
        """
        self._values: typing.Dict[str, typing.Any] = {
            "stepfunctions": stepfunctions,
            "lambda_": lambda_,
        }

    @builtins.property
    def stepfunctions(self) -> typing.List[aws_cdk.aws_stepfunctions.StateMachine]:
        """
        :stability: experimental
        """
        result = self._values.get("stepfunctions")
        assert result is not None, "Required property 'stepfunctions' is missing"
        return result

    @builtins.property
    def lambda_(self) -> aws_cdk.aws_lambda.Function:
        """
        :stability: experimental
        """
        result = self._values.get("lambda_")
        assert result is not None, "Required property 'lambda_' is missing"
        return result

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "EventLoggerCustomLambdaProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdk-seed/stepfunction-event-logger.EventLoggerStandardLambdaProps",
    jsii_struct_bases=[EventLoggerBaseProps],
    name_mapping={
        "stepfunctions": "stepfunctions",
        "datastore": "datastore",
        "event_logging_level": "eventLoggingLevel",
    },
)
class EventLoggerStandardLambdaProps(EventLoggerBaseProps):
    def __init__(
        self,
        *,
        stepfunctions: typing.List[aws_cdk.aws_stepfunctions.StateMachine],
        datastore: Datastore,
        event_logging_level: "EventLoggingLevel",
    ) -> None:
        """
        :param stepfunctions: 
        :param datastore: 
        :param event_logging_level: 

        :stability: experimental
        """
        self._values: typing.Dict[str, typing.Any] = {
            "stepfunctions": stepfunctions,
            "datastore": datastore,
            "event_logging_level": event_logging_level,
        }

    @builtins.property
    def stepfunctions(self) -> typing.List[aws_cdk.aws_stepfunctions.StateMachine]:
        """
        :stability: experimental
        """
        result = self._values.get("stepfunctions")
        assert result is not None, "Required property 'stepfunctions' is missing"
        return result

    @builtins.property
    def datastore(self) -> Datastore:
        """
        :stability: experimental
        """
        result = self._values.get("datastore")
        assert result is not None, "Required property 'datastore' is missing"
        return result

    @builtins.property
    def event_logging_level(self) -> "EventLoggingLevel":
        """
        :stability: experimental
        """
        result = self._values.get("event_logging_level")
        assert result is not None, "Required property 'event_logging_level' is missing"
        return result

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "EventLoggerStandardLambdaProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@cdk-seed/stepfunction-event-logger.EventLoggingLevel")
class EventLoggingLevel(enum.Enum):
    """
    :stability: experimental
    """

    FULL = "FULL"
    """
    :stability: experimental
    """
    SUMMARY = "SUMMARY"
    """
    :stability: experimental
    """


class StepFunctionEventLogger(
    aws_cdk.core.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdk-seed/stepfunction-event-logger.StepFunctionEventLogger",
):
    """
    :stability: experimental
    """

    def __init__(
        self,
        scope: aws_cdk.core.Construct,
        id: builtins.str,
        props: typing.Union[EventLoggerCustomLambdaProps, EventLoggerStandardLambdaProps],
    ) -> None:
        """
        :param scope: -
        :param id: -
        :param props: -

        :stability: experimental
        """
        jsii.create(StepFunctionEventLogger, self, [scope, id, props])

    @jsii.member(jsii_name="createDatastore")
    def create_datastore(
        self,
        sqs_message_processor_function: aws_cdk.aws_lambda.Function,
        datastore: Datastore,
    ) -> None:
        """
        :param sqs_message_processor_function: -
        :param datastore: -

        :stability: experimental
        """
        return jsii.invoke(self, "createDatastore", [sqs_message_processor_function, datastore])

    @jsii.member(jsii_name="createMessageProcessorFunction")
    def create_message_processor_function(
        self,
        event_logging_level: EventLoggingLevel,
        datastore: Datastore,
    ) -> aws_cdk.aws_lambda.Function:
        """
        :param event_logging_level: -
        :param datastore: -

        :stability: experimental
        """
        return jsii.invoke(self, "createMessageProcessorFunction", [event_logging_level, datastore])


__all__ = [
    "Datastore",
    "EventLoggerBaseProps",
    "EventLoggerCustomLambdaProps",
    "EventLoggerStandardLambdaProps",
    "EventLoggingLevel",
    "StepFunctionEventLogger",
]

publication.publish()
